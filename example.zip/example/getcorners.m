function [xpts,ypts] = getcorners(axishandle, amount)

% Author Ronald Ouwerkerk, 2003
% Modified Patryk Radyjowski, 2011

%============================================================================
% Find parent figure for the argument axishandle
%============================================================================
figure(get(axishandle, 'Parent'));

%===========================================================================
% Prepare for interactive collection of ROI boundary points
%===========================================================================
hold on
xpts = zeros(amount,1);
ypts = zeros(amount,1);
n = 0;
but = 1;
BUTN = 0;
KEYB = 1;
done =0;
%===========================================================================
% Loop until right hand mouse button or keayboard is pressed
%===========================================================================
while ~done;  
  %===========================================================================
  % Analyze each buttonpressed event
  %===========================================================================
  keyb_or_butn = waitforbuttonpress;
  if keyb_or_butn == BUTN;
    currpt = get(axishandle, 'CurrentPoint');
    seltype = get(gcf,'SelectionType');
    switch seltype 
    case 'normal',
      but = 1;
    case 'alt',
      but = 2;
    otherwise,
      but = 2;
    end;          
  elseif keyb_or_butn == KEYB
    but = 2;
  end; 
  %===========================================================================
  % Get coordinates of the last buttonpressed event
  %===========================================================================
  xi = currpt(2,1);
  yi = currpt(2,2);
  %===========================================================================
  % Record coordinates obtained and update image
  %===========================================================================
  if (but ==1) && (n < amount)
	n = n+1;
	xpts(n,1) = round(xi);
	ypts(n,1) = round(yi);
    plot(xi,yi,'ro');
	%===========================================================================
	% Draw a line line between the points
    %===========================================================================
	if n > 1
      x=[xpts(n-1), xpts(n)];
      y=[ypts(n-1), ypts(n)];
      plot(x,y,'r');
	end;
  else %if but > 1
      %===========================================================================
	  % Exit for right hand mouse button or keyboard input
      %===========================================================================
      done = 1;
  end;
end;

end